package com.example.health_calendar;

import androidx.annotation.NonNull;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;


public class MainActivity extends Activity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    TextView date;
    Date dt;
    SimpleDateFormat time;
    SimpleDateFormat times;
    Spinner value;
    Spinner exvalue;
    Spinner eatvalue;
    Spinner watervalue;
    Spinner wevalue;
    TextView txt;
    TextView extxt;
    TextView eattxt;
    TextView watertxt;
    TextView weight;
    TextView yesterweint;
    int valueint;
    int total;
    int exvalueint;
    int extotal;
    int eatvalueint;
    int eattotal;
    int watervalueint;
    int watertotal;
    float yesterwe;
    float weightdouble;
    float weightvaluedouble;
    Button.OnClickListener t = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {          // 플러스 마이너스 버튼이 눌리면 숫자를 계산해서 표현해줌
                                               // 데이터 베이스에도 저장
            valueint = Integer.parseInt(value.getSelectedItem().toString());;
            total = Integer.parseInt(txt.getText().toString());
            exvalueint = Integer.parseInt(exvalue.getSelectedItem().toString());;
            extotal = Integer.parseInt(extxt.getText().toString());
            eatvalueint = Integer.parseInt(eatvalue.getSelectedItem().toString());;
            eattotal = Integer.parseInt(eattxt.getText().toString());
            watervalueint = Integer.parseInt(watervalue.getSelectedItem().toString());;
            watertotal = Integer.parseInt(watertxt.getText().toString());
            weightvaluedouble = Float.parseFloat(wevalue.getSelectedItem().toString());
            weightdouble = Float.parseFloat(weight.getText().toString());
            Button btn = (Button)findViewById(v.getId());
            if(v.getId() == R.id.weplus){
                weightdouble += weightvaluedouble;
                float a = Math.round((weightdouble*100)/100.0);
                databaseReference.child("cal").child("weight").setValue(a);
                yesterweint.setText(Float.toString(weightdouble - yesterwe));
            }
            if(v.getId() == R.id.weminus){
                weightdouble -= weightvaluedouble;
                float b = Math.round((weightdouble*100)/100.0);
                databaseReference.child("cal").child("weight").setValue(b);
                yesterweint.setText(Float.toString(weightdouble - yesterwe));
            }
            if(v.getId() == R.id.plus){
                total += valueint;
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.minus){
                total -= valueint;
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.explus){
                total += exvalueint;
                extotal += exvalueint;
                databaseReference.child("cal").child("ex").setValue(extotal);
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.exminus){
                total -= exvalueint;
                extotal -= exvalueint;
                databaseReference.child("cal").child("ex").setValue(extotal);
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.eatplus){
                total += eatvalueint;
                eattotal += eatvalueint;
                databaseReference.child("cal").child("eat").setValue(eattotal);
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.eatminus){
                total -= eatvalueint;
                eattotal -= eatvalueint;
                databaseReference.child("cal").child("eat").setValue(eattotal);
                databaseReference.child("cal").child("total").setValue(total);
            }
            if(v.getId() == R.id.waterplus){
                watertotal += watervalueint;
                databaseReference.child("cal").child("water").setValue(watertotal);

            }
            if(v.getId() == R.id.waterminus){
                watertotal -= watervalueint;
                databaseReference.child("cal").child("water").setValue(watertotal);
            }
            txt.setText(Integer.toString(total));               // 인터페이스에 표시
            extxt.setText(Integer.toString(extotal));
            eattxt.setText(Integer.toString(eattotal));
            watertxt.setText(Integer.toString(watertotal));
            weight.setText(Float.toString(weightdouble));
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt = (TextView) findViewById(R.id.totalcalint);
        extxt = (TextView) findViewById(R.id.excalint);
        eattxt = (TextView) findViewById(R.id.eatcalint);
        watertxt = (TextView) findViewById(R.id.watercalint);
        weight = (TextView) findViewById(R.id.weightint);
        yesterweint = (TextView) findViewById(R.id.yesterint);
        times = new SimpleDateFormat("yyyy-MM-dd"); // 오늘 날짜를 받아옴
        firebaseDatabase = FirebaseDatabase.getInstance();  // 파이어베이스 연동
        String dates = times.format(new Date());
        databaseReference = firebaseDatabase.getReference(dates);
        yesterwe = 70;  // 데이터베이스 값 불러오기 실패로 임의의 값 지정

        date = findViewById(R.id.date);
        time = new SimpleDateFormat("yyyy-MM-dd");
        date.setText(time.format(new Date()));

        findViewById(R.id.plus).setOnClickListener(t);   // onClick 함수에 추가
        findViewById(R.id.minus).setOnClickListener(t);
        findViewById(R.id.exminus).setOnClickListener(t);
        findViewById(R.id.explus).setOnClickListener(t);
        findViewById(R.id.eatminus).setOnClickListener(t);
        findViewById(R.id.eatplus).setOnClickListener(t);
        findViewById(R.id.waterminus).setOnClickListener(t);
        findViewById(R.id.waterplus).setOnClickListener(t);
        findViewById(R.id.weminus).setOnClickListener(t);
        findViewById(R.id.weplus).setOnClickListener(t);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.w("1", "loadPost:onCancelled", databaseError.toException());

            }
        });
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {     // 초기에 한번 데이터베이스에서 가져오고
                                                                                        // 그 이후는 onclick 함수에서 적용
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                total = dataSnapshot.child("cal").child("total").getValue(int.class);
                extotal = dataSnapshot.child("cal").child("ex").getValue(int.class);
                eattotal = dataSnapshot.child("cal").child("eat").getValue(int.class);
                watertotal = dataSnapshot.child("cal").child("water").getValue(int.class);
                weightdouble = dataSnapshot.child("cal").child("weight").getValue(float.class);
                txt.setText(Integer.toString(total));
                extxt.setText(Integer.toString(extotal));
                eattxt.setText(Integer.toString(eattotal));
                watertxt.setText(Integer.toString(watertotal));
                weight.setText(Float.toString(weightdouble));
                yesterweint.setText(Float.toString(weightdouble - yesterwe));
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {      // 데이터가 없을 시 초기값 설정
                databaseReference.child("cal").child("water").setValue(0);
                databaseReference.child("cal").child("weight").setValue(0);
                databaseReference.child("cal").child("total").setValue(0);
                databaseReference.child("cal").child("ex").setValue(0);
                databaseReference.child("cal").child("eat").setValue(0);
                databaseReference.child("memo").child("eat").setValue("none");
                databaseReference.child("memo").child("ex").setValue("none");
            }
        });


        wevalue = (Spinner) findViewById(R.id.wevalue); // 스피너 설정

        wevalue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        value = (Spinner) findViewById(R.id.value);

        value.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        exvalue = (Spinner) findViewById(R.id.exvalue);

        exvalue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        eatvalue = (Spinner) findViewById(R.id.eatvalue);

        eatvalue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        watervalue = (Spinner) findViewById(R.id.watervalue);

        watervalue.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });
        Button calcal = (Button) findViewById(R.id.calcal); // 캘린더 레이아웃으로 이동하기 위한 버튼들
        Button excal = (Button) findViewById(R.id.excalendar);
        Button eatcal = (Button) findViewById(R.id.eatcalendar);
        Button watercal = (Button) findViewById(R.id.watercalendar);
        calcal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), cal.class);
                startActivityForResult(intent, 0);
            }
        });
        excal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), exercise.class);
                startActivityForResult(intent, 0);
            }
        });
        eatcal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), eat.class);
                startActivityForResult(intent, 0);
            }
        });
        watercal.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), water.class);
                startActivityForResult(intent, 0);
            }
        });
    }

}
