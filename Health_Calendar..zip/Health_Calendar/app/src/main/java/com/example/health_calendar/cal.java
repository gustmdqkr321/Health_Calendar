package com.example.health_calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;

public class cal extends Activity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseDatabase Database;
    DatabaseReference dbReference;
    TextView textView;
    TextView when;
    TextView wetxt;
    SimpleDateFormat time;
    SimpleDateFormat times;
    TextView txt;
    Button btnhome;
    CalendarView  mCalendarView;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cal);
        setTitle("cal");
        txt = (TextView) findViewById(R.id.daycal);
        wetxt = (TextView) findViewById(R.id.dayweight);
        times = new SimpleDateFormat("yyyy-MM-dd");
        firebaseDatabase = FirebaseDatabase.getInstance();
        final String dates = times.format(new Date());  // 현재 날짜를 스트링으로 변환 데이터베이스 연동 할때 사용
        databaseReference = firebaseDatabase.getReference();
        mCalendarView = (CalendarView) findViewById(R.id.calendarView2);
        btnhome = (Button) findViewById(R.id.home);
        when = (TextView) findViewById(R.id.when);
        when.setText(dates);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() // 날짜 선택 이벤트
        {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth)
            {
                String date = year + "-" + (month + 1) + "-" + dayOfMonth;
                databaseReference.child(dates).child("cal").child("today").setValue(date);

                when.setText(date); // 선택한 날짜로 설정

            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int cal = dataSnapshot.child(dates).child("cal").child("total").getValue(int.class);
                txt.setText(Integer.toString(cal));
                double weight = dataSnapshot.child(dates).child("cal").child("weight").getValue(double.class);
                wetxt.setText(Double.toString(weight));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        btnhome.setOnClickListener(new View.OnClickListener() {     // 홈버튼 설정
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}