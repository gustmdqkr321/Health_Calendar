package com.example.health_calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;

public class water extends Activity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    TextView when;
    SimpleDateFormat time;
    SimpleDateFormat times;
    TextView txt;
    Button btnhome;
    CalendarView  mCalendarView;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.water);
        setTitle("water");
        txt = (TextView) findViewById(R.id.daycal);
        times = new SimpleDateFormat("yyyy-MM-dd");
        firebaseDatabase = FirebaseDatabase.getInstance();
        String dates = times.format(new Date());
        databaseReference = firebaseDatabase.getReference(dates);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView2);
        btnhome = (Button) findViewById(R.id.home);
        when = (TextView) findViewById(R.id.when);
        when.setText(dates);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() // 날짜 선택 이벤트
        {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth)
            {
                String date = year + "-" + (month + 1) + "-" + dayOfMonth;
                when.setText(date); // 선택한 날짜로 설정

            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int cal = dataSnapshot.child("cal").child("water").getValue(int.class);
                txt.setText(Integer.toString(cal));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("1", "loadPost:onCancelled", databaseError.toException());
            }
        });
        btnhome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
