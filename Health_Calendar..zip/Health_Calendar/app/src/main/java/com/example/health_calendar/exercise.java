package com.example.health_calendar;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;

public class exercise extends Activity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    TextView when;
    SimpleDateFormat time;
    SimpleDateFormat times;
    TextView txt;
    Button btnhome;
    Button form;
    Button ok;
    EditText memo;
    CalendarView  mCalendarView;
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.exercise);
        setTitle("exercise");
        memo = (EditText) findViewById(R.id.memo);
        txt = (TextView) findViewById(R.id.daycal);
        times = new SimpleDateFormat("yyyy-MM-dd");
        firebaseDatabase = FirebaseDatabase.getInstance();
        String dates = times.format(new Date());
        databaseReference = firebaseDatabase.getReference(dates);
        mCalendarView = (CalendarView) findViewById(R.id.calendarView2);
        btnhome = (Button) findViewById(R.id.home);
        form = (Button) findViewById(R.id.form);
        ok = (Button) findViewById(R.id.ok);
        when = (TextView) findViewById(R.id.when);
        when.setText(dates);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() // 날짜 선택 이벤트
        {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth)
            {
                String date = year + "-" + (month + 1) + "-" + dayOfMonth;
                when.setText(date); // 선택한 날짜로 설정

            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int cal = dataSnapshot.child("cal").child("ex").getValue(int.class);
                txt.setText(Integer.toString(cal));
                String memos = dataSnapshot.child("memo").child("ex").getValue(String.class);
                memo.setText(memos);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("1", "loadPost:onCancelled", databaseError.toException());
            }
        });
        btnhome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        form.setOnClickListener(new View.OnClickListener() {  // 메모 수정 버튼
            public void onClick(View v) {
                memo.setEnabled(true);                        // 수정 버튼을 누르면 텍스트를 입력 할 수 있게함
            }
        });
        ok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {                         // 확인 버튼
                memo.setEnabled(false);
                databaseReference.child("memo").child("ex").setValue(memo.getText().toString());
            }
        });                                                  // 확인 버튼을 누르면 텍스트를 입력하지 못하고 데이터베이스에 저장
    }
}